﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Lidgren.Network
{
	/// <summary>
	/// Lidgren Network Library
	/// </summary>
	internal class NamespaceDoc
	{
		// <include file='_Namespace.xml' path='Documentation/*' />
	}
}
