﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Engine.Model.Entities
{
  public enum RoomType
  {
    Unknown = -1,
    Chat = 1,
    Voice = 2,
  }
}
