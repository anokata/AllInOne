﻿using Engine.Model.Client;
using Engine.Model.Entities;
using System;
using System.Net;

namespace Engine.API.StandardAPI.ClientCommands
{
  class ClientConnectToPeerCommand :
      BaseCommand,
      IClientAPICommand
  {
    public void Run(ClientCommandArgs args)
    {
      MessageContent receivedContent = GetContentFormMessage<MessageContent>(args.Message);

      if (receivedContent.RemoteInfo == null)
        throw new ArgumentNullException("info");

      if (receivedContent.PeerPoint == null)
        throw new ArgumentNullException("PeerPoint");

      ClientModel.Peer.ConnectToPeer(receivedContent.RemoteInfo.Nick, receivedContent.PeerPoint);
    }

    [Serializable]
    public class MessageContent
    {
      IPEndPoint peerPoint;
      User remoteInfo;

      public IPEndPoint PeerPoint { get { return peerPoint; } set { peerPoint = value; } }
      public User RemoteInfo { get { return remoteInfo; } set { remoteInfo = value; } }
    }

    public const ushort Id = (ushort)ClientCommand.ConnectToPeer;
  }
}
